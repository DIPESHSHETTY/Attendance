import React, { Component } from 'react'
import Dashboard from './Dashboard'
export default class 



extends Component {
  render() {
    return (
      <div>
           

      <Dashboard />
        
      </div>
    )
  }
}
