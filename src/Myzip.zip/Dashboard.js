import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import './Dashboard.css';
import studentDetails from './studentDetails.json';
import Login from './Login';
import Attendance from './Attendance';
import Settings from './Settings';
import StudentEvents from './StudentEvents';
import Graph from './Graph';
import PieChart from './PieChart';
import sies from './sies.png';

const Dashboard = () => {
  const [student, setStudent] = useState({});

  useEffect(() => {
    setStudent(studentDetails);
  }, []);

  const calculateAttendance = (attendance, type) => {
    if (!attendance) return [];
    return Object.keys(attendance).map((subject) => {
      const totalClasses = attendance[subject].length;
      const attendedClasses = attendance[subject].reduce((acc, curr) => acc + curr, 0);
      return {
        subject,
        percentage: (attendedClasses / totalClasses) * 100,
        type,
      };
    });
  };

  const theoryAttendance = student.attendance?.theory;
  const practicalAttendance = student.attendance?.practical;
  const dates = student.attendance?.dates;

  const theoryAttendanceData = calculateAttendance(theoryAttendance, 'theory');
  const practicalAttendanceData = calculateAttendance(practicalAttendance, 'practical');

  return (
    <Router>
      <div className="dashboard-container">
        <div className="sidebar">
          <div className="logo-container">
            <div className="logo" style={{color:"#ffa726"}}>SIES GST</div>
            <div className="logo-img">
              <img src={sies} alt="Logo" />
            </div>
          </div>
          <nav>
            <ul>
              <li><Link to="/">Dashboard</Link></li>
              <li><Link to="/graph">Attendance Graph</Link></li>
              <li><Link to="/leave-application">Leave Application</Link></li>
            </ul>
          </nav>
          <Settings />
        </div>
        <div className="main-content">
          <div className="header">
            <h1 style={{color:" #2c3e50"}}>STUDENT DASHBOARD</h1>
          </div>
          <div className="content-columns">
            <div className="left-column">
              <Login student={student} />
              <div className="attendance-section">
                <h2>Attendance Records</h2>
                <div className="cards-container">
                  <div className="attendance-card">
                    <Attendance attendance={theoryAttendance} title="Theory " />
                  </div>
                  <div className="attendance-card">
                    <Attendance attendance={practicalAttendance} title="Practical " />
                  </div>
                </div>
              </div>
              <div className="event">
                <StudentEvents studentId={student.studentId} />
              </div>
            </div>
            <div className="right-column">
              <h2>Chart View</h2>
              <div className="charts-container">
                {[...theoryAttendanceData, ...practicalAttendanceData].map((data, index) => (
                  <div className="chart-card" key={index}>
                    <PieChart data={data} />
                    <p>{data.subject}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      
    </Router>
  );
};

export default Dashboard;
